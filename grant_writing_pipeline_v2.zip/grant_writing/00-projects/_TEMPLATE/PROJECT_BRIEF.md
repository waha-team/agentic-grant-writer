# Project Brief: [PROJECT NAME]

> Replace all bracketed text with specifics.

---

## Summary

**One-sentence description:** [e.g., "Localize the Waha Discovery Bible Study app into Farsi to serve the rapidly growing underground church in Iran."]

**Project type:** [Localization / Mobilization / Technology / Other]

**Target funding range (total project cost):** [e.g., $15,000 - $25,000]

**Note:** Individual grant asks will be sized to each foundation's giving patterns (per 990 analysis), not this total. This project may be funded by multiple smaller grants.

## The Problem (This Is the Most Important Section)

[What gap exists? Who is underserved? Why does this matter NOW? Be vivid and specific.]

[Frame this as a problem that a funder would care about solving. Include: the population affected, the geography, the urgency, and what happens if nothing changes.]

[Include at least one data point and, if possible, one human story.]

## What We Will Do

[Specific activities this project involves.]

### Activities & Deliverables

1. [Activity] → [Deliverable]
2. [Activity] → [Deliverable]
3. [Activity] → [Deliverable]

## Who This Serves

- **Primary beneficiaries:** [e.g., Farsi-speaking believers and seekers]
- **Potential reach:** [e.g., 87 million Farsi speakers worldwide]
- **Geographic focus:** [e.g., Iran, Afghanistan, Tajikistan, diaspora]

## Budget

| Category | Estimated Cost |
|----------|---------------|
| [e.g., Translation] | |
| [e.g., Voice Recording] | |
| [e.g., Bible Licensing] | |
| [e.g., QA & Testing] | |
| [e.g., Project Management] | |
| **Total** | |

## Timeline

| Milestone | Target Date |
|-----------|-------------|
| | |
| | |
| | |

## Success Metrics

- [e.g., Language fully deployed on Waha app]
- [e.g., X users in first 6 months]
- [e.g., X Discovery Bible Study groups started]

## Sustainability

[How work continues after grant period. For localization: once deployed, available forever at zero marginal cost.]

## Security Considerations

[Is this in a restricted-access nation? Note sensitivities for proposal writing.]

---

*Created: [DATE] by [NAME]*
