# HUMAN_TODO

> This file is the escalation channel. When Claude Code encounters a decision that requires human judgment, it adds an entry here instead of blocking the pipeline. Check this file regularly.
>
> **Format:** Each entry includes the date, the project name, the pipeline stage, and a clear description of what's needed.

---

## SETUP ITEMS (Complete before first pipeline run)

- [ ] **PAST_GRANTS.md** — Fill in your actual grant history
- [ ] **OUR_ORGANIZATION.md** — Add specific team member names and bios
- [ ] **FINANCIALS_SUMMARY.md** — Add current budget breakdown, audit status
- [ ] **Gather universal attachments:** 501(c)(3) determination letter, most recent 990, board list, financial statements → save in a shared folder
- [ ] **WRITING_SAMPLES/** — Add 2-3 excerpts from past successful proposals or strong LOIs

---

<!-- EXAMPLE ENTRY (delete once real entries appear):

## 2026-02-18 | waha-farsi-localization | 02-deep-research

**Decision needed:** The Kern Family Foundation 990 shows they've never funded international work, but their mission statement mentions "global impact." Include with creative framing or skip?

**Recommended action:** Skip for now; revisit if we develop a domestic training angle.

**Waiting on:** Josh or Alycia to confirm.

-->
